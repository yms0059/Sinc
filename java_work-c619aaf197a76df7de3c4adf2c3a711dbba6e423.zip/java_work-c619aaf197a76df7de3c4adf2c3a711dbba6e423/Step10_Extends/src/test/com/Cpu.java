package test.com;

public class Cpu {

}
