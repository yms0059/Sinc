package test.main;

import test.mypac.HandPhone;
import test.mypac.SmartPhone;

public class MainClass07 {
	public static void main(String[] args) {
		
		//HandPhone 객체를 생성해서 참조값을 변수에 담기
		HandPhone p1=new HandPhone();
		//ClassCastException 발생
		//SmartPhone p2 = (SmartPhone)p1;
		//↑ 캐스팅 오류난다.
		
		//이런거 한번 만들어봐
		
		
	}
}
