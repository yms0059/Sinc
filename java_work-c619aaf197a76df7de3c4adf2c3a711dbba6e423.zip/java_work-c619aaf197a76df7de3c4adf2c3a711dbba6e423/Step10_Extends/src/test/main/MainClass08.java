package test.main;

import test.mypac.B;

public class MainClass08 {
	public static void main(String[] args) {
		//콘솔창에 생성자가 호출되는 순서를 확인하세요!
		new B();
	}
}
