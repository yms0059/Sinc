package test.mypac;

public class B extends A{
	//생성자
	public B(){
		System.out.println("B()생성자 호출됨");
	}
	
}
