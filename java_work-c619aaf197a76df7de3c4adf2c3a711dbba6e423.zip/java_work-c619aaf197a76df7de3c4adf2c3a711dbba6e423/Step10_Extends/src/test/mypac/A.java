package test.mypac;

public class A {
	public A(){
		System.out.println("A()생성자 호출됨");
	}
}
