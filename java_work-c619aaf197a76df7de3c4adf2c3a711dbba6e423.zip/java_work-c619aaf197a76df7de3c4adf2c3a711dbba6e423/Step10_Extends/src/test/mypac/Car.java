package test.mypac;

public class Car { //extends Object 가 생략되어있다.
	
	public void drive(){
		System.out.println("달려요~");
	}
}
