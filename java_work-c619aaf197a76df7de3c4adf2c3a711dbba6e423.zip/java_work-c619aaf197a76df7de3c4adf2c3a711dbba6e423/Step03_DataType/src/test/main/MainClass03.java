package test.main;
/*
 * [java data type]
 * 3. 문자형
 * 
 * -char 형은 문자 한글자를 표현할 수 있다.
 */
public class MainClass03 {
	public static void main(String[] args) {
		//syso + ctrl + space
		System.out.println("메인 메소드가 시작되었습니다.");
		
		char ch1='A';
		char ch2='가';
		char ch3='쀍';
		
		System.out.println("메인 메소드가 종료되었습니다.");
	}
}
