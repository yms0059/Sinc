package test.main;
/*
 * [java data type]
 * 4.논리형
 * 
 * -boolean
 * -참, 거짓을 나타내는 데이터type
 * -종류 : true, false
 */
public class MainClass04 {
	public static void main(String[] args) {
		System.out.println("메인 메소드가 시작되었습니다.");
		
		boolean isWait=true;
		boolean isRun=false;
		boolean isGreater=10>5;
		boolean result=!true;
		boolean result2=true||false;
		boolean result3=true&&false;
		
		System.out.println("메인 메소드가 종료되었습니다.");
	}
}
