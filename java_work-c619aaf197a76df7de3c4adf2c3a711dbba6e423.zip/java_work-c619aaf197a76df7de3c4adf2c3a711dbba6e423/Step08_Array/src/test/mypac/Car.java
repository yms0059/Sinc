package test.mypac;

public class Car {
	//일반 멤버 메소드
	public void drive(){
		System.out.println("조낸 달려요!");
	}
}
