package test.mypac;

public class Person {

}
