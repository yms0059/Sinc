package test.main;

public class MainClass {
	public static void main(String[] args){
		//콘솔창에 Hello, World 문자열 출력하기	
		System.out.println("Hello, World!");
		//콘솔창에 My, World 문자열 출력하기
		System.out.println("My, World!");
	}
}
