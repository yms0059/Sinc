package test.main;

import test.mypac.MyFrame;

public class MainClass01 {
	public static void main(String[] args) {
		//MyFrame 객체 생성하기
		new MyFrame();
	}
}
