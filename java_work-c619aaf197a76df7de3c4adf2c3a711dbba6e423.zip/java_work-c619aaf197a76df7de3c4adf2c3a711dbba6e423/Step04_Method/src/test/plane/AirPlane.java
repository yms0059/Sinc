package test.plane;

public class AirPlane {
	public static void fly(){
		System.out.println("비해애애애애애애앵기이이이이이이이이~");
	}
}
