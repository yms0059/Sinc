package test.main;

public class Person {
	//person 클래스의 static 멤버 메소드
	public static void sing() {
		System.out.println("우워우워우워워워어어~");		
	}
}
