package test.main;

import test.mypac.CarUser;

public class MainClass02 {
	public static void main(String[] args) {
		new CarUser().car.drive();
		new CarUser().useCar();
		new CarUser().useCar2();
	}
}
