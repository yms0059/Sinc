package test.mypac;

public class PhoneStore {

}
