package test.gura;

public class Util {
	//static 멤버 필드
	public static int version=1;
	
	public static void sendMessage(){
		System.out.println("메세지를 전송합니다.");
	}
}
