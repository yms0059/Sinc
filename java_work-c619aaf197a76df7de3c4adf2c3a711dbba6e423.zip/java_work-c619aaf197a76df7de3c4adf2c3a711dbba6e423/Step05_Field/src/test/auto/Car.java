package test.auto;

public class Car {
	//일반 멤버 필드 정의하기
	public String brand="Audi";
	//public 전부공개
	//클래스에서 정의한 것
	public int Crave=1;	
	
	//지역변수는 메소드안에서 정의한 것
	
	//일반 멤버 메소드 정의하기
	public void drive(){
		System.out.println("부르응부르응부릉부릉");
	}
}
