package test.mypac;

public class Wrapper {
	// static 맴버필드 정의하기 
	public static Car car=new Car();
	
}