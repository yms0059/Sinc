package test.mypac;

public class Orange {

}
