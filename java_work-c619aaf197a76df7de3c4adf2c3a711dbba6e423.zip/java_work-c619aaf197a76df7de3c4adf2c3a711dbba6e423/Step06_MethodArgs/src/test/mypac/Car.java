package test.mypac;

//new Car() -> Car a = new Car() Car타입 객체
//new Apple() -> Apple a = new Apple()



public class Car {
	//일반 멤버 메소드
	public void drive(){
		System.out.println("달려요!");
	}
}
