package test.mypac;

public class PrintStream {
	public void println(String abc){
		
	}
}
