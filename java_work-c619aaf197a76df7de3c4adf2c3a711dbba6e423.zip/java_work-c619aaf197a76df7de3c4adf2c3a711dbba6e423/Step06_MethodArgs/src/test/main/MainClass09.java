package test.main;

import test.mypac.Apple;
import test.mypac.Car;
import test.mypac.Orange;

public class MainClass09 {
	public static void main(String[] args) {
		//test1, test2 를 각각 호추해보세요.
		Orange a = new Orange();
		Car b = new Car();
		Apple c = new Apple();
		test1(10<5, a);
		test2("우와우와",b,c);
		
		
	}
	public static void test1(boolean isRun, Orange orange){
		
	}
	public static void test2(String msg, Car car, Apple apple){
		
	}
}
