package test.main;

import test.mypac.Car;

public class MainClass10 {
	public static void main(String[] args) {
		Car car1=new Car();
		Car car2;
		Car car3=null;
		
		car1.drive();
//		car2.drive();
		car3.drive();
	}
}
