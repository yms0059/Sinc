package test.mypac;

public class YourWeapon extends Weapon{
	@Override
	public void attack() {
		System.out.println("널 재정의 하겠다.");
	}
}
