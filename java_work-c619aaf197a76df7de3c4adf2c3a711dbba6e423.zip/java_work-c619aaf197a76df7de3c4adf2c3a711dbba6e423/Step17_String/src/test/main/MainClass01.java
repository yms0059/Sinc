package test.main;

public class MainClass01 {
	public static void main(String[] args) {
		int num1=10;
		int num2=10;
		
		//비교연산자
		//논리연산자
		//연결연산자
		
		if(num1 == num2){
			System.out.println("num1 == num2 : true");
		}
		
		if(num1 != num2){
			System.out.println("num1 != num2 : true");
		}
	}
}
