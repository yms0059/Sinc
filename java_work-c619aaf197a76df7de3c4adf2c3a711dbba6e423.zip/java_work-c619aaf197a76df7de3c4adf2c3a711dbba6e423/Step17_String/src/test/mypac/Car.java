package test.mypac;

public class Car {
	private String name;
	public Car(String name){
		this.name=name;
	}
}
