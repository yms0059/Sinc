package test.mypac;

public class Lottonum {
	private int num;
	public Lottonum(int num){
		this.num=num;
	}
}
