package test.mypac;

public class Apple {
	
}