package test.mypac;

public class HardDisk {

}
